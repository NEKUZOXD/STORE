Io<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="Description" content="SITE NEKUZO XD">
	<meta property="og:type" content="website">
	<meta property="og:title" content="SITE NEKUZO XD">
	<meta property="og:description" content="Ready Kebutuhan Hosting
	">
	<meta property="og:image" content="https://i.ibb.co/r48wNVr/20201107-112732.img">
	<link rel="icon" type="image/png" href="https://i.ibb.co/r48wNVr/20201107-112732.img">
	<link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/style2.css">
	<link rel="stylesheet" href="css/slider.css">
<title>SITE NEKUZO XD</title>

	<script src="js/sweetalert2.min.js"></script>
    <link rel="stylesheet" href="css/sweetalert2.min.css">


</head>


<body>


	
<script>
window.onload = function() {
var h1 = document.getElementsByTagName("h2")[0],
text = h1.innerText || h1.textContent,
split = [], i, lit = 0, timer = null;
for(i = 0; i < text.length; ++i) {
split.push("<span>" + text[i] + "</span>");
}
h1.innerHTML = split.join("");
split = h1.childNodes;

var flicker = function() {
lit += 0.01;
if(lit >= 1) {
clearInterval(timer);
}
for(i = 0; i < split.length; ++i) {
if(Math.random() < lit) {
split[i].className = "neon";
} else {
split[i].className = "";
}
}
}
setInterval(flicker, 100);
}
</script>

 <center>
<div class="box">
                <script type="text/javascript">
                    Swal.fire({
                        title: 'WELCOME TO WEBSITE',
                        text: 'NEKUZO XD. STORE',
                        imageUrl: 'https://i.ibb.co/Mkck4c9/20201127-010702.jpg',
                        imageWidth: 150,
                        imageHeight: 150,
                        imageAlt: 'Custom image',
                    })
                </script>

	
	
<h2 class="nav2">
N E K U Z O . S T O R E
</h2>
<div class="nav">
NEKUZO XD.
</div>
<br><br>
<div style="background:#1ed0ff; margin-top: 5%; color: #fff;">
<center>
	<i class="fa fa-html5 fa-1g" aria-hidden="true" style="margin-right: 10px;"></i>
		<span class="fa-stack fa-lg">
		<i class="fa fa-square fa-stack-2x" style="color: #000;"></i>
		<i class="fa fa-code fa-stack-1x fa-inverse"></i>
		</span>
	<i class="fa fa-css3 fa-1g" aria-hidden="true" style="margin-left: 10px;"></i>
</center>
</div>

<div class="garis-home"></div>

	<div class="slider">
		<figure>
			<div class="slide">
				<img src="https://i.ibb.co/8c72Rts/1.png">
			</div>
 
			<div class="slide">
				<img src="https://i.ibb.co/xfFqcc8/2.png">
			</div>
			
			<div class="slide">
				<img src="https://i.ibb.co/M5sPC07/20201201-000954.jpg">
			</div>
 
			<div class="slide">
				<img src="https://i.ibb.co/9yM1xJ1/4.png">
			</div>
			
			<div class="slide">
				<img src="https://i.ibb.co/NtwNLYY/6.png">
			</div>
 
		</figure>
	</div>


<div class="tab">

		<button type="submit" class="log-cpanel" onclick="location.href='https://vip.eternalhosts.com:2083';" style="border: none;"><i class="fa fa-sign-in" aria-hidden="true"></i> Log Cpanel</button>
		<button type="submit" class="buy" onclick="location.href='#beli';" style="border: none;"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Beli</button>
</div>

<div class="tab2">
	<button onclick="location.href='#cpanel';">
	Cpanel <i class="fa fa-angle-right" aria-hidden="true"></i>
	</button>
	<button onclick="location.href='#script';">
	Kebutuhan Hosting <i class="fa fa-angle-right" aria-hidden="true"></i>
	</button>
	<button onclick="location.href='#web';">
	Web Phising <i class="fa fa-angle-right" aria-hidden="true"></i>
	</button>
	<button onclick="location.href='#domain';">
	Domain <i class="fa fa-angle-right" aria-hidden="true"></i>
	</button>
	<button onclick="location.href='#testi';">
	Testimoni <i class="fa fa-angle-right" aria-hidden="true"></i>
	</button>
	<button onclick="location.href='#kontak';">
	Kontak <i class="fa fa-angle-right" aria-hidden="true"></i>
	</button>
	<button onclick="location.href='#beli';">
	Beli <i class="fa fa-angle-right" aria-hidden="true"></i>
	</button>
	<button onclick="location.href='#server';">
	Server <i class="fa fa-angle-right" aria-hidden="true"></i>
	</button>
</div>



<iframe src="https://raw.githubusercontent.com/anars/blank-audio/master/250-milliseconds-of-silence.mp3" allow="autoplay" id="audio" style="display:none" type="audio/mpeg"></iframe>
<audio class="audio" id="player" autoplay loop controls>
    <source src="https://rawcdn.githack.com/Nafiswatsiq/music/110459efa0903d0307d78b6a0ca38fbc2a060bef/JJ - Still.mp3" type="audio/mp3">
</audio>

<!-- popup -->
		<div id="peraturan">
           <div class="window">
					<div class="popup">Peraturan & pengunaan Domain</div>
				<hr>
				<br>
				<br>
				<div class="harga3">
					
					- Harus menggunakan subdomain<br>
					- Dilarang menggunakan domain server menjadi utama<br>
					- Dilarang membuat web scam / web ilegal<br>
					- Dilarang membuat web mailer<br>
					- Dilarang membuat web Checker<br>
					<br><br>
					CARA MENGGUNAKAN DOMAIN : 
					<br><br>
					<i class="fa fa-check-circle" aria-hidden="true" style="color: #09b051;"></i> namaweblu.domain.com  ( Benar ) 
					<br>
					<i class="fa fa-times-circle" aria-hidden="true" style="color: #ff0000;"></i> domain.com ( Salah )
					<br><br>
					IKUTI PERATURAN YANG TELAH DI BUAT<br>
					MELANGGAR? TERMIN USER TANPA KATA REFF !
				</div>
			   <br>
				<div class="back" onclick="location.href='#';">
				<center><i class="fa fa-chevron-circle-left fa-3x" aria-hidden="true" style="color:#000;"></i></center>

				</div>
           </div>
       </div>
	   
		<div id="coming-soon">
           <div class="window">
					<div class="popup">Coming Soon</div>
				<hr>
				<br>
				<br>
					SCRIPT INI BELUM SELESAI, TUNGGU YAAAA...
			   <br>
				<div class="back" onclick="location.href='#';">
				<center><i class="fa fa-chevron-circle-left fa-3x" aria-hidden="true" style="color:#000;"></i></center>

				</div>
           </div>
       </div>
	   
    <div id="cpanel">
           <div class="window">
					<div class="popup">Cpanel</div>
				<hr>
				<div class="harga2">
				
				<br>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i> Cpanel   = Rp 10k (Disk: 100mb)</li>
				</div>
			    
				
				<button class="peraturan" type="button" onclick="location.href='#peraturan';">Peraturan <i class="fa fa-exclamation-triangle" aria-hidden="true" style="color:#fff;"></i></button>
				
			   
			   <br>
				<div class="back" onclick="location.href='#';">
				<center><i class="fa fa-chevron-circle-left fa-3x" aria-hidden="true" style="color:#000;"></i></center>

				</div>
           </div>
       </div>
	   
	   <div id="script">
           <div class="window">
					<div class="popup">KEBUTUHAN HOSTING</div>
				<hr>
				<div class="harga2">
				<br>
				<center><b> PRICE ADMIN HOST </b></center>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>Admin Host   = Rp 180k/Bulan</li>

				<center><b> PRICE MWHM </b></center>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>Mwhm Mini   = Rp 80k</li>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>Mwhm Medium   = Rp 100k</li>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>Mwhm Ektra   = Rp 130k</li>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>Mwhm Super   = Rp 150k</li>
				
				<center><b> PRICE WHM </b></center>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>Whm Mini   = Rp 30k</li>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>Whm Medium   = Rp 40k</li>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>Whm Ektra   = Rp 50k</li>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>Whm Super   = Rp 60k</li>
				</div>
			   
			   <br>
				<div class="back" onclick="location.href='#';">
				<center><i class="fa fa-chevron-circle-left fa-3x" aria-hidden="true" style="color:#000;"></i></center>

				</div>
           </div>
       </div>
	   
	   <div id="web">
           <div class="window">
					<div class="popup">WEB PHISING</div>
				<hr>
				<div class="harga2">
				<br>
				<center><b> WEB ALL GAME </b></center>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>Web Phising 0x garansi   = Rp 10k</li>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>Web Phising 1x garansi   = Rp 15k</li>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>Web Phising 2x garansi   = Rp 20k</li>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>Web Phising 3x garansi   = Rp 25k</li>
				</div>
			   
			   <br>
				<div class="back" onclick="location.href='#';">
				<center><i class="fa fa-chevron-circle-left fa-3x" aria-hidden="true" style="color:#000;"></i></center>

				</div>
           </div>
       </div>
	   
	   <div id="domain">
           <div class="window">
					<div class="popup">DOMAIN</div>
				<hr>
				<div class="harga">
				<br>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>Domain Freenom   = Rp 1.000/Domain </li>
				<li><i class="fa fa-check-circle-o" aria-hidden="true" style="margin-right: 8px;"></i>Akun Freenom   = Rp 5.000/Akun </li>
				</div>
			   
			   <br>
				<div class="back" onclick="location.href='#';">
				<center><i class="fa fa-chevron-circle-left fa-3x" aria-hidden="true" style="color:#000;"></i></center>

				</div>
           </div>
       </div>
	   
	   <div id="testi">
           <div class="window">
			<div class="scroll">
					<div class="popup">TESTIMONI</div>
				<hr>
				<img src="https://i.ibb.co/ZdtkCDk/20201201-001347.jpg" style="float: left; margin-left: 5%;" onclick="location.href='https://i.ibb.co/ZdtkCDk/20201201-001347.jpg';"></img>
			   
			   <br>
			   
			   <div class="testi-bottom">
				<div class="back" onclick="location.href='#';">
				<center><i class="fa fa-chevron-circle-left fa-3x" aria-hidden="true" style="color:#000;"></i></center>
			   </div>
			   </div>

			</div>
			</div>
       </div>
	   
	   <div id="kontak">
           <div class="window">
					<div class="popup">KONTAK</div>
				<hr>
				<center>
				<button type="submit" class="whatsapp" onclick="location.href='http://wa.me/6282291326823';" style="border: none;">
				<i class="fa fa-whatsapp fa-1g" aria-hidden="true" style="color: #fff;"></i> Whatsapp
				
				</button>
			   
			   <br>
				<div class="back" onclick="location.href='#';">
				<center><i class="fa fa-chevron-circle-left fa-3x" aria-hidden="true" style="color:#000;"></i></center>

				</div>
           </div>
       </div>
	   
	   <div id="beli">
           <div class="window">
					<div class="popup">BELI</div>
				<hr>
				<center>
				<form action="lane.php" method="get">
				<select class="beli" name="buy" required> 
					<option selected="selected" disabled="disabled" value="">pilih</option> 
					<option>Web phising 0x</option> 
					<option>Web phising 1x</option> 
					<option>Web phising 2x</option> 
					<option>Web phising 3x</option> 
					<option>Whm Mini</option>
					<option>Whm Medium</option> 
					<option>Whm Extra</option> 
					<option>Whm Super</option>
					<option>Mwhm Mini</option>
					<option>Mwhm Medium</option>
					<option>Mwhm Extra</option>
					<option>Mwhm Super</option>
					<option>AdminHosting</option>
					<option>Domain Freenom</option>
				</select>
				<button type="submit" class="beli2">
				BELI <i class="fa fa-arrow-circle-right fa-1g" aria-hidden="true"></i>
				</button>
				</form>
				</center>
			   
			   <br>
				<div class="back" onclick="location.href='#';">
				<center><i class="fa fa-chevron-circle-left fa-3x" aria-hidden="true" style="color:#000;"></i></center>

				</div>
           </div>
       </div>
	   
	   <div id="server">
           <div class="window">
					<div class="popup">Server</div>
				<hr>
				<br>
				<center>
				<div class="ETERNAL HOSTING" onclick="location.href='https://vip.eternalhosts .com:2083';">
					<img src="https://i.ibb.co/M6FZbsm/IMG-20201130-230152.jpg"/>
				</div>
				<br>
			<div style="text-align: left; margin-left: 25px;">
				<b>Name server 1</b>
				<br>
				<input type="text" value="ns1.eternalhosts.com" id="ns2" readonly style=" bacground: transparent; border: none; font-size: 17px; width: 125px;">
				<button type="button" onclick="copy_text1()"><i class="fa fa-clone" aria-hidden="true"></i>Copy</button>
				</input>
				<br><br>
				<b>Name server 2</b>
				<br>
				<input type="text" value="ns2.eternalhosts.com" id="ns2" readonly style=" bacground: transparent; border: none; font-size: 17px; width: 125px;">
				<button type="button" onclick="copy_text2()"><i class="fa fa-clone" aria-hidden="true"></i>Copy</button>
				</input>
				<br><br>
				<b>IP Address</b>
				<br>
				<input type="text" value="Kepo Lu Deck" id="ip" readonly style=" bacground: transparent; border: none; font-size: 17px; width: 125px;">
				<button type="button" onclick="copy_text3()"><i class="fa fa-clone" aria-hidden="true"></i>Copy</button>
				</input>
			</div>
				</center>
			   <br>
				<div class="back" onclick="location.href='#';">
				<center><i class="fa fa-chevron-circle-left fa-3x" aria-hidden="true" style="color:#000;"></i></center>

				</div>
           </div>
       </div>
<script type="text/javascript">
    function copy_text1() {
        document.getElementById("ns1").select();
        document.execCommand("copy");
        alert("Text berhasil dicopy Bro!");
    }
</script>
<script type="text/javascript">
    function copy_text2() {
        document.getElementById("ns2").select();
        document.execCommand("copy");
        alert("Text berhasil dicopy Bro!");
    }
</script>
<script type="text/javascript">
    function copy_text3() {
        document.getElementById("ip").select();
        document.execCommand("copy");
        alert("Text berhasil dicopy Bro!");
    }
</script>
<!-- popup -->

</div>
</center>

<footer style="margin-top: 0px;">
	<h3> Tentang Kami</h3>
style="color:#6e6e75;">NEKUZO XD. STORE </a></li>
<li><a href="http://wa.me/6282291326823"> WHATSAPP</a></li>
<li><a href="https://www.facebook.com/profile.php?id=100037238570907"> FACEBOOK</a></li>
<br>



<div class="barcode">
N E K U Z O X D
</div>
</footer>



</body>
</html>
