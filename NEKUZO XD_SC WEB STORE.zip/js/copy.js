<script type="text/javascript">
    function copy_text1() {
        document.getElementById("dompet").select();
        document.execCommand("copy");
        alert("Text berhasil dicopy");
    }
</script>
<script type="text/javascript">
    function copy_text2() {
        document.getElementById("pulsa").select();
        document.execCommand("copy");
        alert("Text berhasil dicopy");
    }
</script>