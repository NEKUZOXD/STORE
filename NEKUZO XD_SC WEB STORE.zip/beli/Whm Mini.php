<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="Description" content="SITE NEKUZO STORE">
	<meta property="og:type" content="website">
	<meta property="og:title" content="SITE NEKUZO STORE">
	<meta property="og:description" content="By NEKUZO XD">
	<meta property="og:image" content="https://i.ibb.co/Mkck4c9/20201127-010702.jpg">
	<link rel="icon" type="image/png" href="https://i.ibb.co/Mkck4c9/20201127-010702.jpg">
	<link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="../css/style.css">
<title>SITE NEKUZO STORE</title>
</head>


<body>

	<div class="box">


<div class="nav">
NEKUZO XD 
</div>
<br><br>
<div style="background:#1ed0ff; margin-top: 5%; color: #fff;">
<center>
	<i class="fa fa-html5 fa-1g" aria-hidden="true" style="margin-right: 10px;"></i>
		<span class="fa-stack fa-lg">
		<i class="fa fa-square fa-stack-2x" style="color: #000;"></i>
		<i class="fa fa-code fa-stack-1x fa-inverse"></i>
		</span>
	<i class="fa fa-css3 fa-1g" aria-hidden="true" style="margin-left: 10px;"></i>
</center>
</div>

<div class="garis-home"></div>
<div class="solusi"><i class="fa fa-shopping-cart fa-2x" aria-hidden="true"></i>  Shoping Cart</div>
<center>
<div class="cart">
Item: <b> WHM MINI</b><br><br>
Jumlah: Rp 30.000-,<br><br>

<script type="text/javascript">
    function copy_text1() {
        document.getElementById("dompet").select();
        document.execCommand("copy");
        alert("Text berhasil dicopy");
    }
</script>
<script type="text/javascript">
    function copy_text2() {
        document.getElementById("pulsa").select();
        document.execCommand("copy");
        alert("Text berhasil dicopy");
    }
</script>
	Silahkan bayar lewat:<br>
<b>Gopay</b><br>
	No: <input type="text" value="082291326823" id="dompet" readonly style=" bacground: transparent; border: none; font-size: 17px; width: 125px">
	<button type="button" onclick="copy_text1()"><i class="fa fa-clone" aria-hidden="true"></i>Copy</button>
	</input>
	<br><br>
	
<b>Dana</b><br>
	No: <input type="text" value="082291326823" id="pulsa" readonly style=" bacground: transparent; border: none; font-size: 17px; width: 125px">
	<button type="button" onclick="copy_text2()"><i class="fa fa-clone" aria-hidden="true"></i>Copy</button>
	</input>
	<br><br>
	
<b>Pulsa Tsel</b><br>
	No: <input type="text" value="082291326823" id="pulsa" readonly style=" bacground: transparent; border: none; font-size: 17px; width: 125px">
	<button type="button" onclick="copy_text2()"><i class="fa fa-clone" aria-hidden="true"></i>Copy</button>
	</input>

<br>
<br>
<form action="selesai/web.php">
	<div class="form">
		</select>
		<br>
		<select name="bayar" required> 
			<option selected="selected" disabled="disabled" value="">pilih pembayaran</option> 			
			<option>Gopay</option>
			<option>Dana</option> 
			<option>Pulsa Tsel</option>
		</select>
	</div>
	<center>
	<button type="submit" class="beli2">
	Lanjut <i class="fa fa-arrow-circle-right fa-1g" aria-hidden="true"></i>
	</button>
	</center>
</form>
<br>
<b style="color: red;">*</b>Setelah membayar harap konfirmasi lewat Whatsapp dan mengirimkan bukti.
</div>
</center>

	</div>

<footer>
	h3> Tentang Kami</h3>
style="color:#6e6e75;">NEKUZO XD </a></li>
<li><a href="http://wa.me/6282291326823"> Whatsapp</a></li>
<li><a href="https://chat.whatsapp.com/FTjQtg8MSTzJ82JpUQwdpp"> Grup Jb</a></li>
<br>



<div class="barcode">
N E K U Z O X D
</div>
</footer>



</body>
</html>